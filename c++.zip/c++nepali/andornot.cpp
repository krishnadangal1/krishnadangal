#include<iostream>
using namespace std;

int main(){

double price;
double finalprice;
string location;

cout<<"enter your pice "<<endl;
cin>>price;

cout<<"Enter Your city "<<endl;
cin>>location;

if(price>=1000||location=="gauradaha"){
	double discount = price*10/100;
	finalprice = price - discount;
}else{
	finalprice = price;
	}
cout<<"your final price is "<<finalprice;
return 0;
}
