
#include<iostream>
using namespace std;

int main(){
	//int a;//normal variable
	int a[5];	//array variable
	a[0]=10;
	a[1]=20;
	a[2]=30;
	a[3]=40;
	a[4]=50;
	
	//using for loop
	for(int i=0;i<5;i++){
		cout<<"value of a is "<<i<<"is"<<a[i]<<endl;
	}
	
	return 0;
}
