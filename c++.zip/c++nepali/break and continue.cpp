/*
break: Terminate from loop or if condination or which;
continuee: Bypass
*/
#include<iostream>
using namespace std;

int main(){
	
	
	return 0;
}
