//this is our first calculator
#include<iostream>
using namespace std;

int main(){
	int a;//variable soesnot sart with sumbol or number
	int b;
	cout<<"Enter first number: "<<endl;
	cin>>a;
	cout<<"Enter second number: "<<endl;
	cin>>b;
		
	cout<<"the sum is "<<(a+b)<<endl;
	cout<<"the diffrence is "<<(a-b)<<endl;
	cout<<"the mul is "<<(a*b)<<endl;
	cout<<"the div is "<<(a/b)<<endl;
	cout<<"the rem is "<<(a%b)<<endl;
	
	return 0;
}
