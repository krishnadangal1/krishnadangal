//comment: programm ma run hunna.

//type:single line comment
/*
multi line comment
*/

#include<iostream>
using namespace std;
int main(){
	//declearing variables
	int a=10;
	double b =10.0;
	//calculating
	double sum=a+b;
	//displaying 
	cout<<"the sum is "<<sum;
	
	
	return 0;
}

