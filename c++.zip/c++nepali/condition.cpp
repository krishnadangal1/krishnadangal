	//if condition
	/*stntax
	if(condition){
	//if condition is right
	}else{
	//if conditing is wrong
	}

	*/ 
#include<iostream>
using namespace std;

int main(){
	cout<<"Welcome to voter cheak app"<<endl;
	
	int age;
	
	cout<<"Enter your age: ";
	cin>>age;
	if(age>=16){
		cout<<"you are  votter"<<endl;
		
		if(age == 16){
			cout<<"we heartly welcome our new votter";
		}
	}else{
		cout<<"you are not votte";
	}

	
	
	return 0;
}
//and &&
// || or
// ! not
