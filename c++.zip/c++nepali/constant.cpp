//costant

#include<iostream>
using namespace std;
#define pi 3.14;

int main(){

	cout<<pi;
	
	return 0;
}
