#include<iostream>
using namespace std;

int main(){
	int i;
for(i=1;i<=4;i++){
	
	
	if(i==3){
		continue;
	}
	cout<<i<<endl;
}
	return 0;
}
