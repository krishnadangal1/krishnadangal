#include<iostream>
using namespace std;

class don{
	private:
	int p,t,r,si;
	public:
	don(int x,int y,int z){
		p=x;
		t=y;
		r=z;
	}
	void process(){
		si=p*t*r/100;
	}
	void output(){
		cout<<"The simple intrest is "<<si;
	}
};
int main(){
	don car(100,4,2);
	don v(car);
	v.process();
	v.output();
	
return 0;
}
