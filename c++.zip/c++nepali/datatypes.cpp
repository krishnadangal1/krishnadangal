//data type
/*
1.int: Use to store number[long,short]
2.float: use to store number with decimal E.G[1.2,3.2]
3.double: float vanda thulo
4.boolen:true or false
5.void: empty
*/
#include<iostream>
using namespace std;

int main(){

int main(){
int a = 10;//variable
float b = 20.5;//variable
double c = 30.5;//variable
bool d = true;//variable
string name = "krishna dangal"; //variable	

cout<<"the value of a is "<<a<<endl;
cout<<"the value of b is "<<b<<endl;
cout<<"the value of c is "<<c<<endl;
cout<<"the value of d is "<<d<<endl;
cout<<"the value of name is "<<name;
	
	return 0;
}
