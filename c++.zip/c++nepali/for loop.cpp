//write a programm that print your name 100 time
/*
synntax: for(init;condition;increment/decrement){
statement
}
*/
#include<iostream>
using namespace std;

int main(){
int i;
for(i=1;i<=100;i++){
cout<<i<<" krishna dangal"<<endl;
}


return 0;
}
