//this programmm print something on screen
#include<iostream>
using namespace std;

int main(){

//std::
cout<< "HELLOW NEPAL"<< endl;//\n or <<endl
cout<< "hellow worls";

return 0;	
}
