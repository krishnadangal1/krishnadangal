#include<iostream>
using namespace std;

int main(){
int Day;
cout<<"Enter number of day ";
cin>>Day;

if(Day==1){
	cout<<"Day is Sunday";
}else if(Day==2){
	cout<<"Day is Monday";
}else if(Day==3){
	cout<<"Day is Tuesday";
}else if(Day==4){
	cout<<"Day is Wednesday";
}else if(Day==5){
	cout<<"Day is Thusday";
}else if(Day==6){
	cout<<"Day is Fryday";
}else if(Day==7){
	cout<<"Day is saturday";
}else{
	cout<<"Invalide date";
}


return 0;
}
