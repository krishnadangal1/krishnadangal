/* loop: process of reapeting something

1.for loop
2.while loop
3.do while loop
*/

#include<iostream>
using namespace std;

int main(){


return 0;
}
