#include<iostream>
using namespace std;
int main(){
	
	Retun 0;
}
