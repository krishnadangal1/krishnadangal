/*
oop:method of creating software.
	:related to disign of internal structure.
	:crate systamic software devlopment.
	
	fitures of opp
	1.Abstraction:hiding the internal details
	2.Encapsulation:data[private],function[public]
	
	class-data[private],function[public]
	fnction acces the data
	3.inheritance:
		make a reusable code. person-----;
	4.polymorphism:
				many forms: run saprate code,using 1 function w
				we can give diffrent work
	
*/
#include<iostream>
using namespace std;

int main(){
	
	
	
	return 0;
}
