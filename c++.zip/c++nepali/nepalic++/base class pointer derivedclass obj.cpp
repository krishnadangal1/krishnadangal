#include<iostream>
using namespace std;
class basichelicopter{
	public:
		void fly(){
			cout<<"Bsic fly ";
		}
	virtual	void land(){
	cout<<"Basic land ";
	}
};
class advancehelicopter: public basichelicopter {
	
	public:
		void land(){
			cout<<"Advance land ";
	}
		void runac(){
			cout<<"Advance AC ";
		}
	
};
int main(){
	basichelicopter *b= new advancehelicopter();
	b->land();
	
	
	
	return 0;
}
