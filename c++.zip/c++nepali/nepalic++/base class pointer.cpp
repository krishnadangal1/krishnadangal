#include<iostream>
using namespace std;
class base{
	public:
		void func1(){
		cout<<"this is base function1 "<<endl;
		}
		void func2(){
		cout<<"this is base function2 "<<endl;
		}
};
class derived: public base{
	public:
		void func3(){
		cout<<"this is Derived function3 ";
		}
};
int main(){
	//we print using pointer
	base *p;//base class pointer
	 p = new derived();	//object
	p->func1();
	p->func2();
	
	
	return 0;
}

