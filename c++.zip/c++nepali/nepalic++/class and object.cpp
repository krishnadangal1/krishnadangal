#include<iostream>
using namespace std;
class circle{
	public:
	double radius;
	
	double findarea(){
		double radius = 3.14*this->radius*this->radius;
	return radius;
	}
};
int main(){
	circle c1,c2;//This is object
	c1.radius = 5;
	c2.radius =3.8;
	
	double radiusofc2 = c2.findarea();
	cout<<"the radius of circle  is "<<radiusofc2;
	
	return 0;
}
