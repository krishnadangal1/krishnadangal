#include<iostream>
using namespace std;
//class : blue print for creating object.
class Person{
	// data
	public:
	int id;
	string name;
	double height; 
	// function
	void getname(){
		cout<<"the name is "<<name;
	}
};

int main(){
		//object justai int i; xa vana hai la Person p; banayou
		Person p;
	p.id=1;
	p.name = "krishna";
	p.height=5.5;
	p.getname();
	
	
	return 0;
}

