//constructor:it is a function which have same name as class name and no return type;
#include<iostream>
using namespace std;

class rectangle{
	private:
		int len;
		int bre;
		
		public:
		rectangle(){
		this->len=1;
		this->bre=1;
		}
		rectangle(int l){
		this->len=l;
		this->bre=1;
	}
		rectangle(int l,int b){
		this->len=l;
		this->bre=b;
	}	
	void area(){
		cout<<"The area is "<<(len*bre)<<endl;
	}
};

int main(){
//	rectangle r(10,20);//constrectur
//	rectangle ra(10,50);
//	r.area();
//	ra.area();
	
	rectangle r(10,30);
	r.area();
	return 0;
}
