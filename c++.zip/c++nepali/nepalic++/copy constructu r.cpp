//copy constructor
#include<iostream>
using namespace std;

class rectangle{
	public:
	int len;
	int bre;
	
	void Getarea(){
		cout<<"the area is "<<(len*bre);
	}
	rectangle(){//by defult constructor
		len = 1;
		bre = 1;
	}
	rectangle(int l, int b){
		 this->len=l;
		 this->bre=b;
	
	}
	rectangle(rectangle &r){
		len = r.len;
		bre = r.bre;
	}
};
int main(){
	rectangle r1(1,5);
	rectangle r2(r1);//copy r1 value in r2
	r2.Getarea();
	
	return 0;
}
