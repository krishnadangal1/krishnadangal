#include<iostream>
using namespace std;
/*private//public//proceted*/
	class rectangle{
		private://acess assifire
		int length;
		int breath;
		public:
		void setlength(int l){
			if(l<1){
				cout<<"Negetive number";
			exit(0);
			
			this->length=1;
			}else{
		this->length = l;
		}
			}
		void setbreath(int b){
		this->breath = b;
		
		}	
		
		void getarea(){
			cout<<"The area is "<<this->length*this->breath;
		
		
		
}
	};
	
int main(){
 
 rectangle rec;
 rec.setlength(-10);
 rec.setbreath(10);
 
 rec.getarea();
 
	return 0;
}
