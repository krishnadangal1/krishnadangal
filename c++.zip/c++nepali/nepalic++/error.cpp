/*
1.Syntax Error====> compiler
2.logical Error===> Dubug
3.Runtime ====> Exception handle
*/

