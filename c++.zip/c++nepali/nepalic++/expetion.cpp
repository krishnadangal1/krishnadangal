#include<iostream>
using namespace std;

int main(){
	
	// IT takes two input from user
	int a,b;
	cout<<"Enter first number "<<endl;
	cin>>a;
	cout<<"Enter second number "<<endl;
	cin>>b;
	
	try{
		if(b==0){
			throw (b);
		}
		
	int result = a/b;
	
	cout<<"Ans is "<<result;	
	}catch(int i){
		cout<<"Cannt Devide by Zero";
	}
	

	
	
	return 0;
}
