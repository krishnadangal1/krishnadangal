#include<iostream>
#include<fstream>
using namespace std;

int main(){
	ifstream i("krish.txt");
	string name;
	int no;
	
	i>>name;
	i>>no;
	i.close();
	cout<<"Name is "<<name<<endl<<"Phone "<<no;
	
	//if(!i)cout<<"No File Found";
	//to find file
	return 0;
}
