#include<iostream>
#include<fstream>
using namespace std;

int main(){
	
	
	ofstream o("krish.txt",ios::trunc);//app,trunc
	o<<"krishna_dangal"<<endl;
	o<<9814922<<endl;
	o.close();
	return 0;
}
