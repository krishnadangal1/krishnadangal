#include<iostream>
using namespace std;
//class Tero;
class mero{
	private:
	int m = 1;
	
	friend class Tero;
};

class Tero{
	mero mo;
	
	public:
void terofunc(){
cout<<"mero mp "<<mo.m;	
}

};
int main(){
	Tero l;
	l.terofunc();
	
	return 0;
}
