//friend function
#include<iostream>
using namespace std;
class Country{
	private:
		int countryid;
		string countryname;
		
		public:
	 Country(){
				countryid=977;
				countryname ="nepal";
			}
	friend void printcountry();		
};

	void printcountry(){
		
		Country c1;//object
		cout<<"Id "<<c1.countryid<<" country name "<<c1.countryname<<endl;
	}
	
	
int main(){
  printcountry();
	
	return 0;
}
