#include<iostream>
using namespace std;
// over ride //over load

class parent{
	public:
	virtual void show(){
			cout<<"I am from parent ";
		}
		
};
class child: public parent{
 	 void show(){
			cout<<"I am from child ";
		}
};
int main(){
	parent *p= new child();//function over ride
	p->show();

	
	return 0;
}

