#include<iostream>
using namespace std;
// over ride //over load

class parent{
	public:
		void show(){
			cout<<"I am from parent ";
		}
		void show(int a){
			cout<<"I am from parent over load.";
			}
};
int main(){
	parent p;
	p.show(1);//function overload

	
	return 0;
}

