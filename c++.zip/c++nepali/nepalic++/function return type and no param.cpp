//2.function with return type and no parameter.
#include<iostream>
using namespace std;
int findsum();
int main(){
	findsum();
	cout<<"the sum is "<<findsum;
	return 0;
}
int findsum(){
	
	return 10+10;
}
