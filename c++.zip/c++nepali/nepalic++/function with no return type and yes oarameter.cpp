//function with no return type and  parameter.
#include<iostream>
using namespace std;
void findsum(int a,int b);
int main(){
	
	findsum(100,30);
	return 0;
}
void findsum(int a,int b){
	
cout<<a+b;
}
