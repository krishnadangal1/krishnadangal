#include<iostream>
using namespace std;
void name();
int main(){
	
	name();
	name();
	
	
	return 0;
}
void name(){
	cout<<"krishna dangal" <<endl;
	

}

