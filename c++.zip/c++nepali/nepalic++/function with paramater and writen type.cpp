//2.function with return type and  parameter.
#include<iostream>
using namespace std;
int findsum(int a,int b);
int main(){
	
	cout<<"the sum is "<<findsum(100,30);
	return 0;
}
int findsum(int a,int b){
	
	return a+b;
}
