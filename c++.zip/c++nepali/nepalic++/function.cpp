/*
function:set of work in certain area 
1.function with no return type and no parameter.
*/
#include<iostream>
using namespace std;
int name();
int main(){
	
	name();
	name();
	name();
	
	
	return 0;
}
int name(){
	cout<<"krishna dangal" <<endl;
	
return 0;
}
