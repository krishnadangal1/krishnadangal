//hierachical inheritance -> 
#include<iostream>
using namespace std;
	class person{
	protected://use by class or sub class
	int id;
	string name;
	
	public:
	void readpersondata(){
	cout<<"Enter your id "<<endl;
	cin>>id;
	cout<<"Enter your name "<<endl;
	cin>>name;
	}
	void displaypersondata(){
	cout<<"Id is "<<id<<endl<<" Name is "<<name;
	}
	};
	class student : public person{
		private:
		int roll;
		
	public:
		
	void getrol(){
		cout<<"Enter roll: "<<endl;
		cin>>roll;
	}
	void displayroll(){
		cout<< "Roll is "<< roll<<endl;
	}
	};
	
	class employee: public person{
	private:
	char post[100];
	double salary;
	
	public:
	void readempdata(){		
	cout<<"Enter your post "<<endl;
	cin>>post;
	cout<<"Enter your salary "<<endl;
	cin>>salary;
	}	
	void empdata(){
	cout<<" post is "<<post<<endl<<" salary is "<<salary;
	}	
	};
	int main(){
	
//	student s1;
//	s1.readpersondata();
//	s1.getrol();
//	s1.displaypersondata();
//	s1.displayroll();
	
	employee e;
	e.readpersondata();
	e.readempdata();
	e.displaypersondata();
	e.readempdata();
	
	return 0;
}
