//hybrid in haritance
#include<iostream>
using namespace std;

class base{
	public:
		base(){
			cout<<"this is defult constrocter of base "<<endl;
		}
		base(int a){
			cout<<"This is parm ctor of base "<<endl;
		}
};
class derived: public base{
	public:
		derived(): base(10){
			cout<<"This is default constrocter of derived "<<endl;
		}
		derived(int a){
			cout<<"This is paramater constrocter of Derived "<<endl;
		}
};

int main(){
	derived d;
	
	return 0;
}
