#include<iostream>
using namespace std;

class rect{
	public:
		int len,bre;
		
		rect(){
		
		}
		rect(int l, int b){
		cout <<"this is pconctructor of rect "<<endl;
			len = l;
			bre = b;
		}
};
class cube: public rect//:in harintace //mode
{
public:
int hei;
cube(){
	cout <<"this is conctructor of cube "<<endl;
}	
cube(int h,int l,int b):rect(l,b){
	hei=h;
}
void cubecal(){
	cout<<"the volume is " <<len*bre*hei;
}	
};

int main(){
	cube c(10,20,30);
	c.cubecal();
	return 0;
}
