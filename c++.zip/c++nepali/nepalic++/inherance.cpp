#include<iostream>
using namespace std;
//inheritance:Using the features of one class to another class
//one class:baxic class
//Another class:Derived class;
class rect{
	public:
		int len,bre;
		
		rect(){
			cout <<"this is conctructor of rect "<<endl;
		}
};
class cube: public rect//:in harintace //mode
{
public:
int hei;
cube(){
	cout <<"this is conctructor of cube "<<endl;
}	
	
};

int main(){
	cube cb;
	
	return 0;
}
