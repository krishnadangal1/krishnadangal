//multileval in haritance
#include<iostream>
using namespace std;
class academicact{
	protected:
		int academictotal;
		
	public:
	void gettotalacd(){
		cout<<"enter academic total mark "<<endl;
		cin>> academictotal;
	}
	void displayacdTotal(){
		cout<<"Academic total mark "<<academictotal<<endl;
	}
	
};

class extraact{
	protected:
	float disciplinemark;
	float sportmark;
	
	public:
		void readextramark(){
		cout<<"enter Discipline mark "<<endl;
		cin>> disciplinemark;
		cout<<"enter sport mark "<<endl;
		cin>> sportmark;			
		}
			void displayextraact(){
		cout<<"Extra total mark Discipline: "<<disciplinemark<<endl;
		cout<<"Extra total mark sport: "<<sportmark<<endl;
	}
};

class result : public academicact,public extraact{
	private:
		float total;
		
	public:	
	void calculateotal(){
		total = academictotal + disciplinemark + sportmark;
	}
	
	void displaytotal(){
		cout<<"Total is "<<total<<endl;
	}
};
int main(){
	
	result r;
	r.gettotalacd();
	r.readextramark();	
	r.calculateotal();
	r.displaytotal();
	return 0;
}

