
//student----exam--result
#include<iostream>
using namespace std;

class student{
	private:
		int roll;
		
	public:
		
	void getrol(){
		cout<<"Enter roll: "<<endl;
		cin>>roll;
	}
	void displayroll(){
		cout<< "Roll is "<< roll<<endl;
	}
};
class exam: public student{
	protected:
		float sub1,sub2;
	
	public:
		void getmarks(){
			cout<<"Enter subject 1 mark "<<endl;
			cin>>sub1;
			cout<<"Enter subject 2 mark "<<endl;
			cin>>sub2;
		}
		void displaymarks(){
		cout<<"Subject 1 mark "<<sub1<<endl;
		cout<<"subject 2 mark "<<sub2<<endl;
		}
};


class result : public exam{
	private:
	float total;
	
	public:
	void calculatetotal(){
		total= sub1+sub2;
	}	
	void displayresult(){
		cout<<"Total is "<<total<<endl;
	}
};


int main(){
	result r;
	r.getrol();
	r.getmarks();
	r.calculatetotal();
	cout<<"After calculating result ";
	
	r.displayroll();
	r.displaymarks();
	r.displayresult();
	
	return 0;
}
