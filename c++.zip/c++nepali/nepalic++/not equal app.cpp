#include<iostream>
using namespace std;
// and &&
// or ||
//not !
int main(){
cout<"welcome to app";

int age;
cout<<"Enter your age ";
cin>>age;

	if(age !=20){
		cout<<"age is no equal to 20: ";
	}
	
return 0;
}
