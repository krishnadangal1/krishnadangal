/*
pointer: It is a variable that contain memory address.

*/
#include<iostream>
using namespace std;

int main(){
int a=10;//normal variable
int *p;//pointer
int **p2;
p2=&p;
	p = &a;
	
	cout<<"The value of A is "<<a<<endl;
	cout<<"The value of p2 is "<<p2<<endl;
	cout<<"The value of p is "<<p;	
	return 0;
}
