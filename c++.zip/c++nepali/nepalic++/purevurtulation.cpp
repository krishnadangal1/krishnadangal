#include<iostream>
using namespace std;
//generalization: car[tesla,bmw,innova[]]
//specialization: rect-->cubeoid 
class Bike{
	public:
	virtual	void start()=0;//pure virtual function
	virtual	void stop()=0;//it is also called abstract class
};

class BulletBike: public Bike{
	public:	
		void start(){
			cout<<"Bullet Bike started ";
		}
		void stop(){
			cout<<"Bullet Bike is stopped ";
		}	
};
class vrbike: public Bike {
	public:	
		void start(){
			cout<<"vr Bike started ";
		}
		void stop(){
			cout<<"vr Bike is stopped ";
		}	
};
class herobike: public Bike {
	public:	
		void start(){
			cout<<"hero Bike started ";
		}
		void stop(){
			cout<<"hero Bike is stopped ";
		}	
};
int main(){
	Bike *b= new BulletBike();
	b->start();

	
	return 0;
}

