#include<iostream>
using namespace std;
// recursive function: function that call itself
int main(){
	//factorial programm
	//5=5*4*3*2*1=120
	
	
	cout<<"Enter number you want to "<<endl;
	int n,fact=1;
	cin>>n;
	
	//using loop
	
	for(int i=n;i>0;i--){
	fact = fact*i;	
	}
	
	cout<<"the factroial is "<<fact;
	return 0;
}
