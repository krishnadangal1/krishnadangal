//write a program in c++ that read you name and say hellow to you
#include<iostream>
using namespace std;
int main(){

	string name;
	
	cout << "Enter your name ";
	cin >> name;	
	
	cout<<"hellow "<<name<<" you are welcome";
	return 0;
}
