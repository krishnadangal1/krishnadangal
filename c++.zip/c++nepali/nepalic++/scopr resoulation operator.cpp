#include<iostream>
using namespace std;
class rectangle{
		public:
		int len;
		int bre;
		
	
		int calculatearea(){
			return len*bre;
		}
		int calculateparimeter();
};

rectangle:: calculateparimeter(){//::scope regulation

return 2*(len + bre);
}

int main(){
	rectangle r;
	r.len=10;
	r.bre=20;
	
	cout<<r.calculatearea()<<endl;
		cout<<r.calculateparimeter();
	
	return 0;
}
