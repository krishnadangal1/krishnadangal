//single in haritance
#include<iostream>
using namespace std;

	class person{
	protected://use by class or sub class
	int id;
	string name;
	
	void readpersondata(){
	cout<<"Enter your id "<<endl;
	cin>>id;
	cout<<"Enter your name "<<endl;
	cin>>name;
	}
	void displaypersondata(){
	cout<<"Id is "<<id<<endl<<" Name is "<<name;
	}
	};
	//new class
	class employee: public person{
	private:
	char post[100];
	double salary;
	
	public:
	void readempdata(){
	readpersondata();
		
	cout<<"Enter your post "<<endl;
	cin>>post;
	cout<<"Enter your salary "<<endl;
	cin>>salary;
	
	}
	
	void empdata(){
	displaypersondata();	
	cout<<" post is "<<post<<endl<<" salary is "<<salary;
	}	
	};
	int main(){
	employee e;
	e.readempdata();
	e.empdata();
	return 0;
	}
