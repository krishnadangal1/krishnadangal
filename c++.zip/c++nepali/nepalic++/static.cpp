#include<iostream>
using namespace std;
//static : 
class Pokhara{
	public:
	int visiterid;
	string visitorname;
	static int count;
	
	Pokhara(){    //this is constructur
		visiterid = 1;
		visitorname = "krishna";
		count++;
	}

	static int gettotalcisitor(){
		
		return count;
	}

};
int Pokhara::count = 0; //scopre regulation


int main(){
	Pokhara p;
	Pokhara a1;
	Pokhara a1v;
	Pokhara a1vc;
			
	
//	char i;	abcd using for loop
//	for (i='a';i<='z';i++){
//		cout<<"Pokhara "<<i<<endl;
//	}
//	
	
	cout<<p.gettotalcisitor();
	// mathi ko ne right xa muni ko ne right xa 
	//cout<<Pokhara::gettotalcisitor();
	
	return 0;
}
