#include<iostream>
using namespace std;
class Software{
	public:
		static double price;
		static int getprice(){
			return price;
		}
};
double Software::price = 25000;


int main(){
	//Software::price = 250;//it can change by this 
	cout<<"The price of software is "<<Software::getprice();
	return 0;
}
