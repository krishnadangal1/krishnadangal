#include<iostream>
using namespace std;


int main(){
int day;
cout<<"Enter number of day ";
cin>>day;

switch(day){

	case 1:
	cout<<"Day is Sunday"<<endl;
	break;
	case2:
	cout<<"Day is Monday"<<endl;
	break;
	case3:
	cout<<"Day is Tuesday"<<endl;
	break;
	case4:
	cout<<"Day is Wednesday"<<endl;
	break;
	case5:
	cout<<"Day is Thirsday"<<endl;
	break;
	case6:
	cout<<"Day is Fryday"<<endl;
	break;
	case7:
	cout<<"Day is Saturday"<<endl;
	break;
	cout<<"invalid input";
}

return 0;
}
/*
switch(var_name)
case 1:
//statement
break;
case 2:
//statement
break; 
*/
