#include<iostream>
using namespace std;

int main(){
int age=20;

int a =(age==20) ? a=1:a=0;

cout<<"value of a is "<<a;

return 0;
}
/*ternery operator syntax: condition ? write value ? wrong value*/
