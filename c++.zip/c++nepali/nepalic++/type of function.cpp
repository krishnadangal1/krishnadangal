/*
type of function
1.function with no return type and no parameter.
2.function with return type and parameter.
3.function with return type and no parameter.
4.function withno return type and with parameter
*/
#include<iostream>
using namespace std;
 void printname();
void main(){
	printname();
	
	return 0;
}
void printname(){
	cout<<"krishna dangal"<<endl;
}

