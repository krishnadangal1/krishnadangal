// type of Inheritance
/*
1.single in haritance 
2.multi leval inheritance
3.hierachical inheritance
4.multipal inheritance
5.hybrid inheritance
*/
#include<iostream>
using namespace std;

int main(){
	
	
	return 0;
}
