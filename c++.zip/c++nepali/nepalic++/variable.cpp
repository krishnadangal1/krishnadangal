//variable constant
//variable: name given to the value
//syntax: data_type variable_name=value; 

#include<iostream>
using namespace std;

int main(){
	
int f =10;
int s=30;
int sum = f+s;

cout << "The sum is "<<sum;

	
	return 0;
}
