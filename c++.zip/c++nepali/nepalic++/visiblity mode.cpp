//visiblity mode:public private:protected
#include<iostream>
using namespace std;

class rect{
	private:
		int l;
	protected:
		int b;
	public:
		int p;
		
		void calc(){
			b = 10;
			l = 20;
			p = 30;
		}
};
class cube: public rect{
	public:
	int cube;
		void calc(){
			b = 10;
			p = 30;
		}
};
int main(){
	cube c;
	c.p=10;//public acess any where in programm;
	c.cube=20;//procted
	
	return 0;
}
