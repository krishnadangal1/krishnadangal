#include<iostream>
using namespace std;

int main(){
		
	int i = 1;
	while(i<=100){
		cout<<i<<"krishna dangal"<<endl;
		i++;
	}
	
	return 0;
}
/*
while lppp syntax

while(condition){

if condition is true

i++;
}

*/
