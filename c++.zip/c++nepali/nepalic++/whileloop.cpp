#include<iostream>
using namespace std;

int main(){
		int i = 100;
	while(i>0){
		cout<<i<<"krishna dangal"<<endl;
		i--;
	}
	
	return 0;
}
