#include<iostream>
using namespace std;
// recursive function: function that call itself
int fact( int num);
int main(){
	//factorial programm

	
	cout<<"Enter number you want to "<<endl;
	int n;
	cin>>n;
	
	
	cout<<"the factroial is "<<fact(n);
	return 0;
}
int fact( int num){
	if(num==1){
		return 1;
	}else{
		return num*fact(num-1);
	}
	
}

//num = 5* fact(4)
// num =4* fact(3)
// num =3* fact(2)
// num =2* fact(1)
// num =1* fact(0)
